from asyncio.trsock import TransportSocket
from curses import newpad
from nis import match
from re import M
from time import sleep
from tkinter import Canvas, Tk, Frame, Button, LEFT, RIGHT, TOP, BOTTOM, NORMAL, DISABLED, StringVar, OptionMenu, messagebox
from tkinter import ttk
from traceback import print_tb
from xml.dom.minidom import Element
from board import generateBoard, saveToFile, readFromFile
import numpy as np

board_size = 600

#[game_settings]
birth_rate = 3
death_rate = 3
game_rounds = 5
change_of_surviving = 0.70
game_speed = 2

class MainWindow(Frame):
    def __init__(self, master):
        Frame.__init__(self, master)
        self.master = master
        self.master.title('Simulation')

        frame = Frame(self.master)
        frame.pack()

        self.canvas = Canvas(frame,  height=board_size,  width=board_size)
        self.canvas.pack(side=BOTTOM)

        window_width = 700
        window_height = 700
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        center_x = int(screen_width/2 - window_width / 2)
        center_y = int(screen_height/2 - window_height / 2)
        self.master.geometry(f'{window_width}x{window_height}+{center_x}+{center_y}')

        self.btn_start = Button(
            frame,
            text="Igraj", 
            state = NORMAL, 
            command = self.generateMap
        )
        self.btn_start.pack(side=LEFT)

        #self.game_board = self.generateMap()
        #saveToFile(self.game_board)
        self.game_board = readFromFile()
        self.play()
    
    def play(self):
        for i in range(game_rounds):
            self.canvas.delete("all")
            self.draw(self.canvas, self.game_board)
            print('aa')
            print(self.game_board[47, 81])
            self.game_board = self.simulation(self.game_board)
            print('bb')
            print(self.game_board[47, 81])
            self.update()
            sleep(game_speed)
        
    def generateMap(self):
        cave_board = generateBoard(change_of_surviving)
        #self.cave_board = self.generateMap(self.game_board)
        for i in range(game_rounds):
            cave_board = self.nextGeneration(cave_board)

            self.canvas.delete("all")
            self.draw(self.canvas, cave_board)
            self.update()
            sleep(game_speed)

        return cave_board

    def nextGeneration(self, map):
        temp_map = np.zeros(map.shape)

        for x, y in np.ndindex(temp_map.shape):
            number_of_neighbors = np.sum(map[x-1:x+2, y-1:y+2]) - map[x, y]

            if map[x, y] == 1 and number_of_neighbors > death_rate:
                temp_map[x, y] = 0
            if map[x, y] == 0 and number_of_neighbors < birth_rate:
                temp_map[x, y] = 1
        
        return temp_map

    def simulation(self, map):
        temp_map = np.zeros(map.shape)
        new_map = []
        print('ok')
        print(temp_map[47, 81])
        for x, y in np.ndindex(temp_map.shape):
            if map[x, y] == 0:
                temp_map[x, y] = 1
            elif map[x, y] == 1:
                temp_map[x, y] = 0
            
            """elif map[x, y] == 2:
                #print(f'waat[x, y] : {map[x, y]}')
                element_below = map[x+1, y]
                print(element_below)
                if element_below == 0:
                    print(f'temp_map[x+1, y] : {temp_map[x+1, y]}')

                    print(f'x: {x+1} y: {y}')
                    temp_map[x+1, y] = 2
                    #temp_map[x, y] = 0
                    print(f'temp_map[x+1, y] : {temp_map[x+1, y]}')
                    print('nooooter')
                    print(print(temp_map[47, 81]))
        
        print('veeeni')
        print(temp_map[47, 81])"""
        return temp_map
    
    #def elementFall(self, element, map):
        #element_below = np.sum(map[x-1:x+2, y-1:y+2]) - map[x, y]

    def simulateElement(self, element):
        if element == 2:
            self.simulateWater()
        elif element == 3:
            self.simulateWood()
        elif element == 4:
            self.simulateSand()
        elif element == 5:
            self.simulateFire()

    def simulateWater(self):
        print('a')
    
    def simulateWood(self):
        print('a')

    def simulateSand(self):
        print('a')

    def simulateFire(self):
        print('a')

    def draw(self, canvas, board):
        game_board = board
        t_size = board_size/len(game_board)

        for i in range(len(game_board)):
            for j in range(len(game_board[i])):
                curr_element = game_board[j][i]
                x = i * t_size
                y = j * t_size

                if(curr_element == 0):
                    canvas.create_rectangle(x, y, x + t_size, y + t_size, fill="#3e2b20", outline="#3e2b20")
                elif(curr_element == 1):
                    #canvas.create_oval(x, y, x + t_size, y + t_size, fill="black")
                    canvas.create_rectangle(x, y, x + t_size, y + t_size, fill="#241913", outline="#241913")
                elif(curr_element == 2):
                    canvas.create_rectangle(x, y, x + t_size, y + t_size, fill="#66D3FA", outline="#66D3FA")
                    #https://www.schemecolor.com/css-family-blue.php

def main(): 
    root = Tk()
    app = MainWindow(root)
    app.mainloop()

if __name__ == '__main__':
    main()